import java.io.IOException;  
import java.io.PrintWriter;  
import java.util.List;  
  
import javax.servlet.ServletException;  
import javax.servlet.annotation.WebServlet;  
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;  
@WebServlet("/ViewServlet")  
public class ViewServlet extends HttpServlet {  
    protected void doGet(HttpServletRequest request, HttpServletResponse response)   
               throws ServletException, IOException {  
        response.setContentType("text/html");  
        PrintWriter out=response.getWriter(); 
        out.println("<head>");
        out.println("<link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css\" integrity=\"sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T\" crossorigin=\"anonymous\">");
        out.println("</head>");
        out.println("<body>");
        out.println("<header>");
        out.println("<nav class='navbar navbar-expand-md navbar-dark' style='background-color: black'>");
        out.println("<div><p class=\"navbar-brand\"> User Management App </p></div>");
        out.println("</nav><header><br>");
        out.println("<div class=\"row\"><div class=\"container\"><h3 class=\"text-center\">List of Users</h3><hr><div class=\"container text-left\">");
        out.println("<a href='index.html'>Add New Faculty</a></div><br>"); 
                List<fac> list=facDao.getAllFaculties();  
        out.print("<table class='table table-bordered'");  
        out.print("<tr><th>Id</th><th>Name</th><th>Password</th><th>Email</th><th>Image Path</th><th>Phone</th><th>Address</th><th>Edit</th><th>Delete</th></tr>");  
        for(fac e:list){  
         out.print("<tr><td>"+e.getId()+"</td><td>"+e.getName()+"</td><td>"+e.getPassword()+"</td><td>"+e.getEmail()+"</td><td>"+e.getImage()+"</td><td>"+e.getPhone()+"</td><td>"+e.getAddress()+"</td><td><a href='EditServlet?id="+e.getId()+"'>edit</a></td><td><a href='DeleteServlet?id="+e.getId()+"'>delete</a></td></tr>");  
        }  
        out.print("</table>");  
          out.println("</div></body>");
        out.close();  
    }  
}  