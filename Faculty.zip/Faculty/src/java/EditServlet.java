import java.io.IOException;  
import java.io.PrintWriter;  
  
import javax.servlet.ServletException;  
import javax.servlet.annotation.WebServlet;  
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;  
@WebServlet("/EditServlet")  
public class EditServlet extends HttpServlet {  
    protected void doGet(HttpServletRequest request, HttpServletResponse response)   
           throws ServletException, IOException {  
        response.setContentType("text/html");  
        PrintWriter out=response.getWriter();  
        
         out.println("<head>");
        out.println("<link rel=\"stylesheet\" href=\"https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css\" integrity=\"sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T\" crossorigin=\"anonymous\">");
        out.print("<style>table {border-collapse: collapse; width: 500px;} tr {widht: 450px;} td {    padding-top: .5em;    padding-bottom: .5em;} input{padding:10px}</style>");
        out.println("</head>");
        out.println("<body>");
        out.println("<header>");
        out.println("<nav class='navbar navbar-expand-md navbar-dark' style='background-color: black'>");
        out.println("<div><p class=\"navbar-brand\"> <h1>Admin</h1></p></div>");
        out.println("</nav><header><br>");
        out.println("<div class=\"row\"><div class=\"container\"><h3 class=\"text-center\">Update Details</h3><hr><div class=\"container text-left\">");
         
        String sid=request.getParameter("id");  
        String id=(sid);  
        fac e=facDao.getFacultyId(id);  
        out.print("<div class=\"container col-md-5\"><div class=\"card\"><div class=\"card-body\">");
        out.print("<form action='EditServlet2' method='post'>");  
        out.print("<table>");  
        
        out.print("<tr><td>ID: </td><td><input  name='id' value='"+e.getId()+"'/></td></tr>");  
        out.print("<tr><td>Name:</td><td><input type='text' name='name' value='"+e.getName()+"'/></td></tr>");  
        out.print("<tr><td>Password:</td><td><input type='password' name='password' value='"+e.getPassword()+"'/></td></tr>");  
        out.print("<tr><td>Email:</td><td><input type='email' name='email' value='"+e.getEmail()+"'/></td></tr>");  
        out.print("<tr><td>Image Path: </td><td><input name='img' value='"+e.getImage()+"'/></td></tr>"); 
        out.print("<tr><td>Phone: </td><td><input  name='phone' value='"+e.getPhone()+"'/></td></tr>"); 
        out.print("<tr><td>Addess: </td><td><input  name='address' value='"+e.getAddress()+"'/></td></tr>"); 
        out.print("<tr><td colspan='2'><center/><input  style='background-color:#000000; color:#ffffff' type='submit' value='Edit & Save '/></td></tr><center>");  
        out.print("</table>");  
        out.print("</form>");  
        
        out.print("</div></div></div>");
          out.print("</body>");
        out.close();  
    }  
}    


