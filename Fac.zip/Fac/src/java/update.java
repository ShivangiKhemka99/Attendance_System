import java.io.IOException; 
import java.io.PrintWriter; 
import java.sql.Connection; 
import java.sql.DriverManager;
import java.sql.PreparedStatement; 
  
import javax.servlet.ServletException; 
import javax.servlet.annotation.WebServlet; 
import javax.servlet.http.HttpServlet; 
import javax.servlet.http.HttpServletRequest; 
import javax.servlet.http.HttpServletResponse; 
  

 
  
// Servlet Name 
@WebServlet("/update") 
public class update extends HttpServlet { 
    private static final long serialVersionUID = 1L; 
  
    protected void doPost(HttpServletRequest request,  
HttpServletResponse response) 
        throws ServletException, IOException 
    { 
        try { 
             Class.forName("com.mysql.jdbc.Driver");

            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/attendance_system", "root", "root");                  
  
         
  
            // Create a SQL query to insert data into demo table 
            // demo table consists of two columns, so two '?' is used 
            
            PreparedStatement st = con 
                   .prepareStatement("insert into fac values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"); 
            PreparedStatement stm = con 
                   .prepareStatement("insert into ml values(?,?,?,?,?,?,?,?,?,?)"); 
  
            // For the first parameter, 
            // get the data using request object 
            // sets the data to st pointer 
            st.setString(1, request.getParameter("opt0")); 
            st.setString(2, request.getParameter("opt1")); 
            st.setString(3, request.getParameter("opt2")); 
            st.setString(4, request.getParameter("opt3")); 
            st.setString(5, request.getParameter("opt4")); 
            st.setString(6, request.getParameter("opt5")); 
            st.setString(7, request.getParameter("opt6")); 
            st.setString(8, request.getParameter("hey")); 
            st.setString(9, request.getParameter("opt7")); 
            st.setString(10, request.getParameter("opt12")); 
            st.setInt(11, Integer.valueOf(request.getParameter("opt11"))); 
            st.setString(12, request.getParameter("opt8")); 
            st.setString(13, request.getParameter("opt9")); 
            st.setInt(14, Integer.valueOf(request.getParameter("opt10"))); 
            st.setString(15, request.getParameter("opt13")); 
            st.setInt(16, Integer.valueOf(request.getParameter("opt14"))); 
            st.executeUpdate(); 
            st.setString(1, request.getParameter("opt20")); 
            st.setString(2, request.getParameter("opt21")); 
            st.setString(3, request.getParameter("opt15")); 
            st.setString(4, request.getParameter("opt16")); 
            st.setString(5, request.getParameter("opt17")); 
            st.setString(6, request.getParameter("opt18")); 
            st.setString(7, request.getParameter("opt19")); 
            st.setString(8, request.getParameter("hey1")); 
            st.setString(9, request.getParameter("opt7")); 
            st.setString(10, request.getParameter("opt12")); 
            st.setInt(11, Integer.valueOf(request.getParameter("opt11"))); 
           st.setString(12, request.getParameter("opt8")); 
            st.setString(13, request.getParameter("opt9"));  
            st.setInt(14, Integer.valueOf(request.getParameter("opt10"))); 
            st.setString(15, request.getParameter("opt13")); 
            st.setInt(16, Integer.valueOf(request.getParameter("opt14"))); 
            st.executeUpdate(); 
            stm.setString(1, request.getParameter("opt7")); 
            stm.setString(2, request.getParameter("opt12")); 
            stm.setInt(3, Integer.valueOf(request.getParameter("opt11"))); 
            stm.setString(4, request.getParameter("opt8")); 
            stm.setString(5, request.getParameter("opt9")); 
            stm.setInt(6, Integer.valueOf(request.getParameter("opt10"))); 
            stm.setInt(7, Integer.valueOf(request.getParameter("opt1"))); 
            stm.setString(8, request.getParameter("opt13"));
            stm.setInt(9, Integer.valueOf(request.getParameter("opt14")));
            stm.setString(10, request.getParameter("opt0")); 
            stm.executeUpdate(); 
            stm.setString(1, request.getParameter("opt7")); 
            stm.setString(2, request.getParameter("opt12")); 
            stm.setInt(3, Integer.valueOf(request.getParameter("opt11"))); 
            stm.setString(4, request.getParameter("opt8")); 
            stm.setString(5, request.getParameter("opt9")); 
            stm.setInt(6, Integer.valueOf(request.getParameter("opt10"))); 
            stm.setInt(7, Integer.valueOf(request.getParameter("opt21"))); 
            stm.setString(8, request.getParameter("opt13")); 
            stm.setInt(9, Integer.valueOf(request.getParameter("opt14")));
            stm.setString(10, request.getParameter("opt20")); 
            stm.executeUpdate(); 
            // Close all the connections 
            
            st.close(); 
            stm.close();
            con.close(); 
            
            // Get a writer pointer  
            // to display the successful result 
            PrintWriter out = response.getWriter(); 
            out.println("<html><body><b>Successfully Inserted"
                        + "</b></body></html>"); 
        } 
        catch (Exception e) { 
            e.printStackTrace(); 
        } 
    } 
}