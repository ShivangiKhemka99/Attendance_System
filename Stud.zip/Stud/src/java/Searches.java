
import java.io.*;

import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;

import javax.servlet.http.*;

@WebServlet(value = "/Searches")
public class Searches extends HttpServlet {

       public void doGet(HttpServletRequest request, HttpServletResponse response)

                     throws ServletException, IOException {

              response.setContentType("text/html");

              PrintWriter out = response.getWriter();        
 
              int sem=Integer.parseInt(request.getParameter("Semester Value"));

              try{

                     Class.forName("com.mysql.jdbc.Driver");

                     java.sql.Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/attendance_system","root","root");                   

                     PreparedStatement ps=con.prepareStatement("select * from subjects where Semester=?");

                   
                     ps.setInt(1, sem);

                     out.print("<table width=25% border=1>");

                     out.print("<center><h1>Result:</h1></center>");

                     ResultSet rs=ps.executeQuery();                

                     /* Printing column names */

                     ResultSetMetaData rsmd=rs.getMetaData();

                     while(rs.next())

                        {

                     System.out.print("<tr>");

                     System.out.print("<th>"+rsmd.getColumnName(1)+"</th>");

                        out.print("<td>"+rs.getString(1)+"</td></tr>");

                        out.print("<th>"+rsmd.getColumnName(2)+"</th>");

                        out.print("<td>"+rs.getString(2)+"</td></tr>");

                        out.print("<th>"+rsmd.getColumnName(3)+"</th>");

                        out.print("<td>"+rs.getString(3)+"</td></tr>");

                        out.print("<th>"+rsmd.getColumnName(4)+"</th>");

                        out.print("<td>"+rs.getString(4)+"</td></tr>"); 
                        
                        out.print("<th>"+rsmd.getColumnName(5)+"</th>");

                        out.print("<td>"+rs.getString(5)+"</td></tr>"); 
                        
                        out.print("<th>"+rsmd.getColumnName(6)+"</th>");

                        out.print("<td>"+rs.getString(6)+"</td></tr>");
                        
                        out.print("<th>"+rsmd.getColumnName(7)+"</th>");

                        out.print("<td>"+rs.getString(7)+"</td></tr>"); 
                        
                        out.print("<th>"+rsmd.getColumnName(8)+"</th>");

                        out.print("<td>"+rs.getString(8)+"</td></tr>"); 

                     }

                     out.print("</table>");

 

              }catch (Exception e2)

                {

                    e2.printStackTrace();

                }

 

              finally{out.close();

                }

       }

 

}