/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author shiva
 */
public class fac {
    private String msg;  


public String getmsg() {  
    return msg;  
}  
public void setmsg(String msg) {  
    this.msg = msg;  
} 
}
