import java.io.FileOutputStream;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/*
 *
 * @author priya
 */
@WebServlet(value = "/GeneratePDF")
public class GeneratePDF extends HttpServlet {
 private static final long serialVersionUID= 1L;
 
    /*
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */public GeneratePDF(){
         super();
     }
     public void init(ServletConfig config) throws ServletException{
           
     }
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        HttpSession session=request.getSession(false);
       
        
        try {
            Document doc=new Document();
            PdfWriter.getInstance(doc, new FileOutputStream("C://Users//shiva//Downloads//Student_Details.pdf"));
            doc.open();
            Paragraph p=new Paragraph();
            p.add("Attendance Details");
            p.setAlignment(Element.ALIGN_CENTER);
            doc.add(p);
            doc.add(Chunk.NEWLINE);
            doc.add(Chunk.NEWLINE);
            PdfPTable table=new PdfPTable(new float[] {5,15,15,15,15,15,15});
            table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell("Attendance Date");
            table.addCell("Course Code");
            table.addCell("Emp no.");
            table.addCell("Period From");
            table.addCell("Period To");
            table.addCell("Total Hours");
            table.addCell("Student");
            table.setHeaderRows(1);
            PdfPCell[] cells=table.getRow(0).getCells();
            for(int j=0;j<cells.length;j++){
                cells[j].setBackgroundColor(BaseColor.GRAY);
            }
            String name=request.getParameter("Sub"); 
             Class.forName("com.mysql.jdbc.Driver");
                     
                     java.sql.Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/attendance_system","root","root");                  

                     PreparedStatement ps=con.prepareStatement("select * from ml where subject=?");
                     ps.setString(1,name);
                     ResultSet rs=ps.executeQuery();                

                     /* Printing column names */

                     ResultSetMetaData rsmd=rs.getMetaData();
                     
while(rs.next()){
                         table.addCell(rs.getString(1));
                         table.addCell(rs.getString(2));
                         table.addCell(rs.getString(3));
                         table.addCell(rs.getString(4));
                         table.addCell(rs.getString(5));
                         table.addCell(String.valueOf(rs.getInt(6)));
                         table.addCell(String.valueOf(rs.getInt(7)));
                     }

            doc.add(table);
            doc.close();
            /* TODO output your page here. You may use following sample code. */
            
        }catch (Exception e2)

                {

                    e2.printStackTrace();

                }
        finally {
            out.close();
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

 
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}