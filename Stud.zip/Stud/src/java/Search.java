import java.io.*;

import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpSession;
import javax.servlet.http.*;
@WebServlet(value = "/Search")
public class Search extends HttpServlet {

       public void doGet(HttpServletRequest request, HttpServletResponse response)

                     throws ServletException, IOException {

              response.setContentType("text/html");
HttpSession session=request.getSession();
              PrintWriter out = response.getWriter();        

              String name=request.getParameter("Subject"); 
              //int sem=Integer.parseInt(request.getParameter("Semester"));

              try{

                     Class.forName("com.mysql.jdbc.Driver");

                  java.sql.Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/attendance_system","root","root");                

                     PreparedStatement ps=con.prepareStatement("select * from ml where subject=? and RollNo = ?");

                     ps.setString(1,name); 
                     ps.setString(2, (String)session.getAttribute("name"));
//out.print((String)session.getAttribute("name"));
                     out.print("<table width=25% border=1>");

                     out.print("<center><h1>Result:</h1></center>");

                     ResultSet rs=ps.executeQuery();                

                     /* Printing column names */

                     ResultSetMetaData rsmd=rs.getMetaData();

                     while(rs.next())

                        {

                     System.out.print("<tr>");

                     System.out.print("<td>"+rsmd.getColumnName(1)+"</td>");

                        out.print("<td>"+rs.getString(1)+"</td></tr>");

                        out.print("<tr><td>"+rsmd.getColumnName(2)+"</td>");

                        out.print("<td>"+rs.getString(2)+"</td></tr>");

                        out.print("<tr><td>"+rsmd.getColumnName(3)+"</td>");

                        out.print("<td>"+rs.getString(3)+"</td></tr>");

                        out.print("<tr><td>"+rsmd.getColumnName(4)+"</td>");

                        out.print("<td>"+rs.getString(4)+"</td></tr>"); 
                        
                        out.print("<tr><td>"+rsmd.getColumnName(5)+"</td>");

                        out.print("<td>"+rs.getString(5)+"</td></tr>"); 
                        
                        out.print("<tr><td>"+rsmd.getColumnName(6)+"</td>");

                        out.print("<td>"+rs.getString(6)+"</td></tr>");
                        
                        out.print("<tr><td>"+rsmd.getColumnName(7)+"</td>");

                        out.print("<td>"+rs.getString(7)+"</td></tr>"); 
                        
                     }

                     out.print("</table>");
                   
 

              }catch (Exception e2)

                {

                    e2.printStackTrace();

                }

 

              finally{out.close();

                }

       }

 

}