/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author shiva
 */import java.util.*;  
import java.sql.*;  
  
public class facDao {  
  
    public static Connection getConnection(){  
        Connection con=null;  
        try{  
            Class.forName("com.mysql.jdbc.Driver");  
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/attendance_system", "root", "root");
            
        }catch(Exception ex){System.out.println(ex);}  
        return con;  
    }  
    public static int save(fac e)
    {  
        int status=0;  
        try{  
            Connection con=facDao.getConnection();  
            PreparedStatement ps;  
            ps = con.prepareStatement("insert into message(student_id,faculty_id, msg) values ('CB.EN.U4CSE17257','1',?);");  
            ps.setString(1,e.getmsg());  
            status=ps.executeUpdate();  
            con.close();  
        }catch(Exception ex){ex.printStackTrace();}  
          
        return status;  
    }  
}  